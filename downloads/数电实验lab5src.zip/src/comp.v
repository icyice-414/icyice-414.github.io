// module for comparator
module comp #(parameter n = 8) ( // add default to run in vivado
    input  [n-1:0] a,
    input  [n-1:0] b,
    output reg      agb,  // a > b
    output reg      aeb,  // a = b
    output reg      alb   // a < b
);
    integer i;  // loop variable
    reg     quit;  // decide whether to end the loop

    always @(*) begin
        agb = 0; alb = 0; aeb = 1;  // assume a = b by default
        quit = 0;  // when quit == 1, the loop will end
        for (i = n - 1; i >= 0 && !quit; i = i - 1) begin
            if (a[i] > b[i]) begin
                agb = 1; alb = 0; aeb = 0;  // a is greater
                quit = 1;
            end
            else if (a[i] < b[i]) begin
                agb = 0; alb = 1; aeb = 0;  // b is greater
                quit = 1;
            end
        end
    end
endmodule