// module for 2to
module mux_2to1 #(parameter n = 8) ( // add default to run in vivado
    input      [n-1:0] in0,
    input      [n-1:0] in1,
    input              addr,   // 0: out = in0; 1: out = in1
    output reg [n-1:0] out
);
    always @(*) begin
        if (addr == 0) begin
            out = in0;
        end
        else begin
            out = in1;
        end
    end
endmodule