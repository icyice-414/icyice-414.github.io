module min_8 #(parameter n = 8)(
    input[n-1:0] a,
    input[n-1:0] b,
    output reg[n-1:0] out
);

    integer i;
    reg     quit;

    always @(*) begin
        out = b; // assume b is less
        quit = 0; // start the loop
        for (i = n - 1; i >= 0 && !quit; i = i - 1) begin
            if (a[i] < b[i]) begin // we can tell a is less
                out = a;
                quit = 1;
            end
            else if (a[i] > b[i]) begin // we can tell b is less
                quit = 1;
            end
        end
    end
endmodule