// module for mode comparator
module ModeComparator #(parameter n = 8)(
    input[n-1:0]      a,
    input[n-1:0]      b,
    input             m, // y = 0 means maximum, y = 1 means minimum, other inputs are illegal
    output reg[n-1:0] y
);

    wire agb; // a is greater than b
    reg [n-1:0] min_out;
    reg [n-1:0] max_out;

    comp #(.n(n)) comp1(
        .a(a), .b(b), 
        .agb(agb), .aeb(), .alb()
    );

    always @(*) begin
        if (agb == 1) begin // a is greater than b
            max_out = a;
            min_out = b;
        end
        else begin // a is less than b
            min_out = a;
            max_out = b;
        end

        if (m == 1) y = min_out;
        else y = max_out;
    end
endmodule