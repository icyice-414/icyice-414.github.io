//------------------------------------------------------------------------------
// Module: sync_ff
// Description:
//   双触发器同步器。
//   用于将异步输入同步到 clk 时钟域，降低亚稳态传播风险。
//------------------------------------------------------------------------------
module sync_ff (
    input  wire clk,       // 时钟信号
    input  wire reset,     // 异步复位，高有效
    input  wire async_in,  // 异步输入信号
    output reg  sync_out   // 同步后的输出信号
);

    reg sync_reg1;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            sync_reg1 <= 1'b0;
            sync_out  <= 1'b0;
        end else begin
            sync_reg1 <= async_in;
            sync_out  <= sync_reg1;
        end
    end

endmodule
