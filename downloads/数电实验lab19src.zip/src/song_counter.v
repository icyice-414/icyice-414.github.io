//------------------------------------------------------------------------------
// Module: song_counter
// Description:
//   2 位歌曲序号计数器。
//   每次 en 有效时切换到下一首歌曲。
//------------------------------------------------------------------------------
module song_counter (
    input  wire       clk,    // 时钟信号
    input  wire       reset,  // 异步复位，高有效
    input  wire       en,     // 计数使能，高有效
    output reg  [1:0] song    // 当前歌曲序号
);

    always @(posedge clk or posedge reset) begin
        if (reset)
            song <= 2'b00;
        else if (en)
            song <= song + 1'b1;
    end

endmodule
