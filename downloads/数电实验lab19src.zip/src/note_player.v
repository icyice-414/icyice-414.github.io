//------------------------------------------------------------------------------
// Module: note_player
// Description:
//   单音符播放顶层模块。
//   根据音符编码读取频率控制字，并调用 DDS 生成对应频率的正弦采样。
//------------------------------------------------------------------------------
module note_player (
    input  wire        clk,               // 时钟信号
    input  wire        reset,             // 异步复位，高有效
    input  wire        play_enable,       // 播放使能
    input  wire [5:0]  note_to_load,      // 待加载音符编码
    input  wire [5:0]  duration_to_load,  // 待加载音符持续时间
    input  wire        load_new_note,     // 新音符加载请求
    input  wire        sampling_pulse,    // 采样脉冲
    input  wire        beat,              // 节拍脉冲
    output wire        note_done,         // 当前音符播放完成
    output wire        sample_ready,      // DDS 新采样有效
    output wire [15:0] sample             // DDS 采样输出
);

    wire        timer_clear;
    wire        load;
    wire        timer_done;
    wire [5:0]  addr;
    wire [19:0] dout;
    wire [21:0] k_full;

    // 播放关闭时复位音符寄存器和 DDS，避免继续输出旧音符
    wire R = reset || (!play_enable);

    // 音符播放控制状态机
    note_player_controller u_controller (
        .clk           (clk),
        .reset         (reset),
        .play_enable   (play_enable),
        .timer_done    (timer_done),
        .load_new_note (load_new_note),
        .timer_clear   (timer_clear),
        .note_done     (note_done),
        .load          (load)
    );

    // 音符持续时间计时器
    note_timer u_timer (
        .clk              (clk),
        .reset            (1'b0),
        .timer_clear      (timer_clear),
        .beat             (beat),
        .duration_to_load (duration_to_load),
        .timer_done       (timer_done)
    );

    // 锁存当前音符编码，作为 frequency_rom 地址
    note_reg u_reg (
        .clk          (clk),
        .reset        (R),
        .load         (load),
        .note_to_load (note_to_load),
        .q            (addr)
    );

    // 读取音符对应的频率控制字
    frequency_rom u_rom (
        .clk  (clk),
        .addr (addr),
        .dout (dout)
    );

    // frequency_rom 输出为 20 位，DDS 需要 22 位频率控制字
    assign k_full = {2'b00, dout};

    // DDS 输出对应音符频率的正弦波采样
    dds u_dds (
        .clk              (clk),
        .reset            (R),
        .k                (k_full),
        .sampling_pulse   (sampling_pulse),
        .new_sample_ready (sample_ready),
        .sample           (sample)
    );

endmodule
