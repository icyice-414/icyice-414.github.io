`timescale 1ns / 1ps

//------------------------------------------------------------------------------
// Module: music_player
// Description:
//   音乐播放器核心模块。
//   负责按键控制、节拍生成、歌曲读取、音符播放以及音频采样输出。
//------------------------------------------------------------------------------
module music_player #(
    parameter sim = 0  // 仿真模式：1 时使用较快节拍
) (
    input  wire        clk,         // 时钟信号
    input  wire        reset,       // 异步复位，高有效
    input  wire        play_pause,  // 播放/暂停切换脉冲
    input  wire        next,        // 下一首切换脉冲
    input  wire        NewFrame,    // 音频接口提供的异步采样帧信号
    output wire [15:0] sample,      // 正弦波采样输出
    output wire        play,        // 播放状态
    output wire [1:0]  song         // 当前歌曲序号
);

    wire       ready;       // 同步后的采样脉冲
    wire       beat;        // 节拍基准脉冲
    wire       reset_play;  // 播放链路复位信号
    wire       song_done;   // 歌曲播放完成标志
    wire       note_done;   // 当前音符播放完成标志
    wire       new_note;    // 新音符加载脉冲
    wire [5:0] note;        // 当前音符编码
    wire [5:0] duration;    // 当前音符持续时间

    // 将音频接口的异步 NewFrame 转换为系统时钟域内的单周期脉冲
    sync_pulse u_sync_pulse (
        .clk   (clk),
        .reset (reset),
        .in    (NewFrame),
        .ready (ready)
    );

    // 节拍基准分频器
    divider #(
        .n            (sim ? 64 : 2_000_000),
        .counter_bits (sim ? 6  : 21)
    ) u_divider (
        .clk   (clk),
        .reset (reset),
        .beat  (beat)
    );

    // 主控制器
    mcu u_mcu (
        .clk        (clk),
        .reset      (reset),
        .play_pause (play_pause),
        .next       (next),
        .song_done  (song_done),
        .play       (play),
        .song       (song),
        .reset_play (reset_play)
    );

    // 读取当前歌曲的音符和时长
    song_reader u_song_reader (
        .clk       (clk),
        .reset     (reset || reset_play),
        .play      (play),
        .song      (song),
        .note_done (note_done),
        .song_done (song_done),
        .note      (note),
        .duration  (duration),
        .dout      (),          // 调试输出未使用
        .new_note  (new_note)
    );

    // 根据当前音符生成对应频率的采样数据
    note_player u_note_player (
        .clk              (clk),
        .reset            (reset || reset_play),
        .play_enable      (play),
        .note_to_load     (note),
        .duration_to_load (duration),
        .load_new_note    (new_note),
        .sampling_pulse   (ready),
        .beat             (beat),
        .note_done        (note_done),
        .sample_ready     (),   // 调试输出未使用
        .sample           (sample)
    );

endmodule
