//------------------------------------------------------------------------------
// Module: sync_pulse
// Description:
//   异步输入同步与上升沿检测模块。
//   先通过两级寄存器同步，再在检测到上升沿时输出单周期 ready 脉冲。
//------------------------------------------------------------------------------
module sync_pulse (
    input  wire clk,    // 时钟信号
    input  wire reset,  // 异步复位，高有效
    input  wire in,     // 异步输入信号
    output reg  ready   // 同步后的单周期上升沿脉冲
);

    reg [1:0] sync_reg;  // 两级同步寄存器
    reg       in_prev;   // 上一拍同步信号，用于边沿检测

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            sync_reg <= 2'b00;
            in_prev  <= 1'b0;
            ready    <= 1'b0;
        end else begin
            sync_reg <= {sync_reg[0], in};
            in_prev  <= sync_reg[1];
            ready    <= sync_reg[1] & ~in_prev;
        end
    end

endmodule
