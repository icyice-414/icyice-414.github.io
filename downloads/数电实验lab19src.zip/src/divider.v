//------------------------------------------------------------------------------
// Module: divider
// Description:
//   分频器/节拍发生器。
//   计数达到 n-1 时输出一个时钟周期宽度的 beat 脉冲。
//------------------------------------------------------------------------------
module divider #(
    parameter n            = 1000,  // 分频计数值
    parameter counter_bits = 10     // 计数器位宽
) (
    input  wire clk,    // 时钟信号
    input  wire reset,  // 异步复位，高有效
    output reg  beat    // 分频输出脉冲
);

    reg [counter_bits-1:0] cnt;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            cnt  <= {counter_bits{1'b0}};
            beat <= 1'b0;
        end else begin
            if (cnt == n - 1) begin
                cnt  <= {counter_bits{1'b0}};
                beat <= 1'b1;
            end else begin
                cnt  <= cnt + 1'b1;
                beat <= 1'b0;
            end
        end
    end

endmodule
