// ============================================================================
// Module      : button_unit
// Description : 可配置的按键处理单元。
//               通过 sim 参数选择消抖滤波器的仿真/硬件配置；输出为消抖后
//               上升沿对应的单周期脉冲。
// ============================================================================

module button_unit #(
    parameter sim = 0       // 消抖模块参数：通常 0 表示硬件模式，1 表示仿真模式
) (
    input  wire clk,        // 系统时钟
    input  wire reset,      // 异步高电平复位
    input  wire ButtonIn,   // 原始按键输入，可能存在抖动且与 clk 异步
    output wire ButtonOut   // 消抖后的上升沿单周期脉冲
);

    wire synced;     // 同步后的按键信号
    wire debounced;  // 消抖后的稳定按键信号

    // 将异步按键输入同步到 clk 时钟域。
    sync_ff u_sync (
        .clk      (clk),
        .reset    (reset),
        .async_in (ButtonIn),
        .sync_out (synced)
    );

    // 消抖滤波器：sim 参数由顶层传入，便于仿真时缩短消抖时间。
    debounce_filter #(
        .sim(sim)
    ) u_debounce (
        .clk        (clk),
        .reset      (reset),
        .signal_in  (synced),
        .signal_out (debounced)
    );

    // 保存上一拍消抖信号，用于生成上升沿单周期脉冲。
    reg debounced_reg;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            debounced_reg <= 1'b0;
        end else begin
            debounced_reg <= debounced;
        end
    end

    // 上升沿检测：当前为 1 且上一拍为 0。
    assign ButtonOut = debounced & ~debounced_reg;

endmodule
