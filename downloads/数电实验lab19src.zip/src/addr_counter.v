// ============================================================================
// Module      : addr_counter
// Description : 地址计数器。
//               在 note_done 有效时累加 5 位音符地址 q，并与歌曲编号 song
//               拼接得到 7 位 ROM 访问地址 addr。
// ============================================================================

module addr_counter (
    input  wire       clk,        // 系统时钟
    input  wire       reset,      // 异步高电平复位
    input  wire       note_done,  // 音符播放完成脉冲/计数使能
    input  wire [1:0] song,       // 歌曲编号，用作高 2 位地址
    output reg  [4:0] q,          // 当前歌曲内部的 5 位音符地址
    output wire [6:0] addr,       // 拼接后的 ROM 地址：{song, q}
    output wire       co          // q 到达最大值且 note_done 有效时产生进位
);

    // 将 2 位歌曲编号与 5 位音符地址拼接成 7 位地址。
    assign addr = {song[1:0], q[4:0]};

    // 当 q 已经为 31，且本周期收到 note_done 时，提示计数将回绕。
    assign co = (q == 5'b11111) && note_done;

    // 地址计数器：复位清零；每次音符完成后地址加 1。
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            q <= 5'b00000;
        end else if (note_done) begin
            q <= q + 1'b1;
        end else begin
            q <= q;
        end
    end

endmodule
