`timescale 1ns / 1ps

//------------------------------------------------------------------------------
// Module: mcu
// Description:
//   音乐播放器主控制器。
//   根据播放/暂停、下一首、播放完成信号控制 play、reset_play 和歌曲序号。
//------------------------------------------------------------------------------
module mcu (
    input  wire       clk,         // 时钟信号
    input  wire       reset,       // 异步复位，高有效
    input  wire       play_pause,  // 播放/暂停切换脉冲
    input  wire       next,        // 下一首切换脉冲
    input  wire       song_done,   // 当前歌曲播放完成
    output reg        play,        // 播放使能状态
    output wire [1:0] song,        // 当前歌曲序号
    output reg        reset_play   // 播放链路复位信号
);

    // 状态编码
    localparam RESET = 2'b00,
               PAUSE = 2'b01,
               PLAY  = 2'b10,
               NEXT  = 2'b11;

    reg [1:0] current_state;
    reg [1:0] next_state;

    reg next_song;  // 歌曲序号计数使能

    // 状态寄存器
    always @(posedge clk or posedge reset) begin
        if (reset)
            current_state <= RESET;
        else
            current_state <= next_state;
    end

    // 次态逻辑
    always @(*) begin
        case (current_state)
            RESET: begin
                next_state = PAUSE;
            end

            PAUSE: begin
                if (play_pause)
                    next_state = PLAY;
                else if (next)
                    next_state = NEXT;
                else
                    next_state = PAUSE;
            end

            PLAY: begin
                if (play_pause)
                    next_state = PAUSE;
                else if (next)
                    next_state = NEXT;
                else if (song_done)
                    next_state = RESET;
                else
                    next_state = PLAY;
            end

            NEXT: begin
                next_state = PLAY;
            end

            default: begin
                next_state = RESET;
            end
        endcase
    end

    // 输出逻辑
    always @(*) begin
        case (current_state)
            RESET: begin
                play       = 1'b0;
                next_song  = 1'b0;
                reset_play = 1'b1;
            end

            PAUSE: begin
                play       = 1'b0;
                next_song  = 1'b0;
                reset_play = 1'b0;
            end

            PLAY: begin
                play       = 1'b1;
                next_song  = 1'b0;
                reset_play = 1'b0;
            end

            NEXT: begin
                play       = 1'b0;
                next_song  = 1'b1;
                reset_play = 1'b1;
            end

            default: begin
                play       = 1'b0;
                next_song  = 1'b0;
                reset_play = 1'b0;
            end
        endcase
    end

    // 歌曲序号计数器
    song_counter u_song_counter (
        .clk   (clk),
        .reset (reset),
        .en    (next_song),
        .song  (song)
    );

endmodule
