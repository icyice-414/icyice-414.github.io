//------------------------------------------------------------------------------
// Module: song_reader
// Description:
//   歌曲读取模块。
//   通过地址计数器读取 song_rom，输出当前音符 note 和持续时间 duration。
//------------------------------------------------------------------------------
module song_reader (
    input  wire        clk,        // 时钟信号
    input  wire        reset,      // 异步复位，高有效
    input  wire        play,       // 播放使能
    input  wire [1:0]  song,       // 当前歌曲序号
    input  wire        note_done,  // 当前音符播放完成
    output wire        song_done,  // 当前歌曲播放完成
    output wire [5:0]  note,       // 当前音符编码
    output wire [5:0]  duration,   // 当前音符持续时间
    output wire [11:0] dout,       // song_rom 原始输出
    output reg         new_note    // 新音符加载脉冲
);

    wire       co;    // 地址计数器进位输出
    wire [4:0] q;     // 当前歌曲内部音符地址
    wire [6:0] addr;  // 拼接后的 song_rom 地址

    localparam RESET     = 2'b00,
               NEW_NOTE  = 2'b01,
               WAIT      = 2'b10,
               NEXT_NOTE = 2'b11;

    reg [1:0] current_state;
    reg [1:0] next_state;

    // 状态寄存器
    always @(posedge clk or posedge reset) begin
        if (reset)
            current_state <= RESET;
        else
            current_state <= next_state;
    end

    // 次态逻辑
    always @(*) begin
        case (current_state)
            RESET: begin
                if (play)
                    next_state = NEW_NOTE;
                else
                    next_state = RESET;
            end

            NEW_NOTE: begin
                next_state = WAIT;
            end

            WAIT: begin
                if (play) begin
                    if (note_done)
                        next_state = NEW_NOTE;
                    else
                        next_state = WAIT;
                end else begin
                    next_state = RESET;
                end
            end

            NEXT_NOTE: begin
                next_state = NEW_NOTE;
            end

            default: begin
                next_state = RESET;
            end
        endcase
    end

    // 输出控制：NEW_NOTE 状态下产生单周期加载脉冲
    always @(*) begin
        case (current_state)
            RESET: begin
                new_note = 1'b0;
            end

            NEW_NOTE: begin
                new_note = 1'b1;
            end

            WAIT: begin
                new_note = 1'b0;
            end

            NEXT_NOTE: begin
                new_note = 1'b0;
            end

            default: begin
                new_note = 1'b0;
            end
        endcase
    end

    // song_rom 输出格式：[11:6] 为音符，[5:0] 为持续时间
    assign note     = dout[11:6];
    assign duration = dout[5:0];

    // 地址计数器：根据歌曲序号和音符序号生成 ROM 地址
    addr_counter u_addr_counter (
        .clk       (clk),
        .reset     (reset),
        .note_done (note_done),
        .song      (song),
        .q         (q),
        .addr      (addr),
        .co        (co)
    );

    // 歌曲 ROM
    song_rom u_song_rom (
        .clk  (clk),
        .addr (addr),
        .dout (dout)
    );

    // 歌曲结束检测
    song_end_detector u_song_end_detector (
        .clk       (clk),
        .reset     (reset),
        .co        (co),
        .dout      (dout),
        .song_done (song_done)
    );

endmodule
