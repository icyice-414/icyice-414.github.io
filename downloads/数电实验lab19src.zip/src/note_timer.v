//------------------------------------------------------------------------------
// Module: note_timer
// Description:
//   音符时长定时器。
//   以 beat 为计数单位，计数达到 duration_to_load 时产生 timer_done。
//------------------------------------------------------------------------------
module note_timer (
    input  wire       clk,               // 时钟信号
    input  wire       reset,             // 异步复位，高有效
    input  wire       timer_clear,       // 计时器清零
    input  wire       beat,              // 节拍脉冲
    input  wire [5:0] duration_to_load,  // 目标持续时间
    output reg        timer_done         // 时长到达标志
);

    reg [5:0] beat_counter;

    // beat_counter 只在 beat 到来时递增
    always @(posedge clk or posedge reset) begin
        if (reset || timer_clear) begin
            beat_counter <= 6'b0;
        end else if (beat) begin
            if (beat_counter < duration_to_load)
                beat_counter <= beat_counter + 1'b1;
        end
    end

    // 组合判断当前音符是否已经播放到指定时长
    always @(*) begin
        if (beat_counter == duration_to_load)
            timer_done = 1'b1;
        else
            timer_done = 1'b0;
    end

endmodule
