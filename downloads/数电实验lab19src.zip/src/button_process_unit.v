// ============================================================================
// Module      : button_process_unit
// Description : 按键处理单元。
//               对异步按键输入依次进行同步、消抖和上升沿检测，最终输出
//               一个时钟周期宽度的 ButtonOut 脉冲。
// ============================================================================

module button_process_unit (
    input  wire clk,        // 系统时钟
    input  wire reset,      // 异步高电平复位
    input  wire ButtonIn,   // 原始按键输入，可能存在抖动且与 clk 异步
    output wire ButtonOut   // 消抖后的上升沿单周期脉冲
);

    wire synced;     // 同步到 clk 时钟域后的按键信号
    wire debounced;  // 消抖后的稳定按键信号

    // 两级触发器同步，降低异步输入带来的亚稳态风险。
    sync_ff u_sync (
        .clk      (clk),
        .reset    (reset),
        .async_in (ButtonIn),
        .sync_out (synced)
    );

    // 按键消抖滤波；本模块固定使用非仿真参数 sim = 0。
    debounce_filter #(
        .sim(0)
    ) u_debounce (
        .clk        (clk),
        .reset      (reset),
        .signal_in  (synced),
        .signal_out (debounced)
    );

    // 保存上一拍消抖信号，用于检测上升沿。
    reg debounced_reg;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            debounced_reg <= 1'b0;
        end else begin
            debounced_reg <= debounced;
        end
    end

    // 当 debounced 当前为 1、上一拍为 0 时，输出一个时钟周期的高脉冲。
    assign ButtonOut = debounced & ~debounced_reg;

endmodule
