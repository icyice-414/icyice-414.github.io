`timescale 1ns / 1ps

//------------------------------------------------------------------------------
// Module: MusicPLayerTop
// Description:
//   音乐播放器工程顶层模块。
//   连接时钟、按键处理、音乐播放器核心和音频 Codec 接口。
//------------------------------------------------------------------------------
module MusicPLayerTop (
    // Clock
    input  wire       clk,          // 板载 100 MHz 时钟
    input  wire       reset,        // 复位信号，高有效

    // Push buttons
    input  wire       play_button,  // 播放/暂停按键，高有效
    input  wire       next_button,  // 下一首按键，高有效

    // Codec interface
    input  wire       ADC_SDATA,
    output wire       DAC_SDATA,
    output wire       BCLK,
    output wire       MCLK,
    output wire       LRCLK,
    inout  wire       SCL,
    inout  wire       SDA,

    // LED outputs
    output wire [1:0] song,         // 当前歌曲序号
    output wire       play          // 播放状态指示
);

    wire sys_clk;
    wire audio_clk;

    // 生成系统时钟和音频接口时钟
    DCM_Audio DCM_inst (
        .clk_out1 (sys_clk),
        .clk_out2 (audio_clk),
        .reset    (1'b0),
        .locked   (),
        .clk_in1  (clk)
    );

    //--------------------------------------------------------------------------
    // Button processor units
    //--------------------------------------------------------------------------

    wire next;
    wire play_pause;

    // 下一首按键：同步、消抖、单脉冲
    button_process_unit u_next_button_process (
        .clk       (sys_clk),
        .reset     (reset),
        .ButtonIn  (next_button),
        .ButtonOut (next)
    );

    // 播放/暂停按键：同步、消抖、单脉冲
    button_process_unit u_play_button_process (
        .clk       (sys_clk),
        .reset     (reset),
        .ButtonIn  (play_button),
        .ButtonOut (play_pause)
    );

    //--------------------------------------------------------------------------
    // Music player sample generator
    //--------------------------------------------------------------------------

    reg play_pause_reg;
    reg next_reg;

    wire play_pause_pulse;
    wire next_pulse;

    // 对按键信号再次做边沿检测，确保控制信号为单周期脉冲
    always @(posedge sys_clk or posedge reset) begin
        if (reset) begin
            play_pause_reg <= 1'b0;
            next_reg       <= 1'b0;
        end else begin
            play_pause_reg <= play_pause;
            next_reg       <= next;
        end
    end

    assign play_pause_pulse = play_pause & ~play_pause_reg;
    assign next_pulse       = next       & ~next_reg;

    wire [15:0] sample;
    wire        NewFrame;

    music_player u_music_player (
        .clk        (sys_clk),
        .reset      (reset),
        .play_pause (play_pause_pulse),
        .next       (next_pulse),
        .NewFrame   (NewFrame),
        .sample     (sample),
        .play       (play),
        .song       (song)
    );

    //--------------------------------------------------------------------------
    // Codec interface
    //--------------------------------------------------------------------------

    AudioInterface u_audio_interface (
        .clk           (audio_clk),
        .reset         (reset),
        .BCLK          (BCLK),
        .LRCLK         (LRCLK),
        .MCLK          (MCLK),
        .ADC_SDATA     (ADC_SDATA),
        .DAC_SDATA     (DAC_SDATA),
        .LeftPlayData  ({sample, 8'd0}),
        .RightPlayData ({sample, 8'd0}),
        .LeftRecData   (),
        .RightRecData  (),
        .NewFrame      (NewFrame),
        .SCL           (SCL),
        .SDA           (SDA),
        .error         ()
    );

endmodule
