//------------------------------------------------------------------------------
// Module: debounce_filter
// Description:
//   按键消抖滤波器。
//   当输入信号与当前稳定状态不同且持续达到阈值后，才更新输出状态。
//------------------------------------------------------------------------------
module debounce_filter #(
    parameter sim = 0  // 仿真模式：1 时使用较小计数阈值
) (
    input       clk,         // 时钟信号
    input       reset,       // 异步复位，高有效
    input       signal_in,   // 待消抖输入信号
    output reg  signal_out   // 消抖后的稳定输出
);

    // 实际阈值：20 ms @ 100 MHz = 2_000_000 个时钟周期
    // 仿真阈值：2 个周期，便于快速观察
    localparam [21:0] SIM_CNT_MAX  = 22'd2;
    localparam [21:0] REAL_CNT_MAX = 22'd2_000_000;

    wire [21:0] cnt_max = sim ? SIM_CNT_MAX : REAL_CNT_MAX;

    reg [21:0] cnt;           // 稳定计数器
    reg        stable_state;  // 当前确认的稳定状态

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            cnt          <= 22'd0;
            stable_state <= 1'b0;
            signal_out   <= 1'b0;
        end else begin
            if (signal_in != stable_state) begin
                // 输入与稳定状态不同，开始计数确认是否为有效变化
                if (cnt == cnt_max - 1'b1) begin
                    cnt          <= 22'd0;
                    stable_state <= signal_in;
                    signal_out   <= signal_in;
                end else begin
                    cnt <= cnt + 1'b1;
                end
            end else begin
                // 输入回到稳定状态，计数清零
                cnt <= 22'd0;
            end
        end
    end

endmodule
