//------------------------------------------------------------------------------
// Module: note_reg
// Description:
//   音符寄存器。
//   在 load 有效时锁存新的音符编码。
//------------------------------------------------------------------------------
module note_reg (
    input  wire       clk,           // 时钟信号
    input  wire       reset,         // 异步复位，高有效
    input  wire       load,          // 加载使能
    input  wire [5:0] note_to_load,  // 待加载音符编码
    output reg  [5:0] q              // 当前音符编码
);

    always @(posedge clk or posedge reset) begin
        if (reset)
            q <= 6'b0;
        else if (load)
            q <= note_to_load;
    end

endmodule
