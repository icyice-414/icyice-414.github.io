//------------------------------------------------------------------------------
// Module: dds
// Description:
//   DDS（Direct Digital Synthesizer）顶层模块。
//   通过相位累加器产生 ROM 地址，再经正弦 ROM 和数据处理模块输出采样值。
//------------------------------------------------------------------------------
module dds (
    input  wire        clk,               // 时钟信号
    input  wire        reset,             // 异步复位，高有效
    input  wire [21:0] k,                 // 频率控制字
    input  wire        sampling_pulse,    // 采样使能脉冲
    output wire        new_sample_ready,  // 新采样数据有效标志
    output wire [15:0] sample             // 输出正弦波采样值
);

    // 内部连线
    wire [21:0] raw_addr;    // 相位累加器当前值
    wire [21:0] adder_out;   // 相位累加器加法结果
    wire [9:0]  rom_addr;    // 正弦 ROM 地址
    wire [15:0] raw_data;    // ROM 输出的原始数据
    wire [15:0] data;        // 符号处理后的数据
    wire        area_bit;    // 延迟一拍后的相位最高位

    // 相位累加器：raw_addr <= raw_addr + k
    adder_22 u_adder (
        .a   (k),
        .b   (raw_addr),
        .sum (adder_out)
    );

    dff_en_rst #(
        .WIDTH (22)
    ) u_phase_reg (
        .clk   (clk),
        .reset (reset),
        .en    (sampling_pulse),
        .d     (adder_out),
        .q     (raw_addr)
    );

    // 地址处理：根据象限完成地址截取/镜像
    addr_process u_addr_process (
        .raw_addr (raw_addr),
        .rom_addr (rom_addr)
    );

    // 正弦 ROM：输出 1/4 周期波形数据
    sine_rom u_sine_rom (
        .clk  (clk),
        .addr (rom_addr),
        .dout (raw_data)
    );

    // 相位最高位打一拍，与 ROM 输出数据时序对齐
    dff_en_rst #(
        .WIDTH (1)
    ) u_area_bit_reg (
        .clk   (clk),
        .reset (reset),
        .en    (1'b1),
        .d     (raw_addr[21]),
        .q     (area_bit)
    );

    // 根据相位区域生成正/负半周期数据
    data_process u_data_process (
        .raw_data (raw_data),
        .area_bit (area_bit),
        .data     (data)
    );

    // 输出采样寄存器
    dff_en_rst #(
        .WIDTH (16)
    ) u_sample_reg (
        .clk   (clk),
        .reset (reset),
        .en    (sampling_pulse),
        .d     (data),
        .q     (sample)
    );

    // 采样有效标志打一拍输出
    dff_en_rst #(
        .WIDTH (1)
    ) u_ready_reg (
        .clk   (clk),
        .reset (reset),
        .en    (1'b1),
        .d     (sampling_pulse),
        .q     (new_sample_ready)
    );

endmodule
