`timescale 1ns/1ps

module sync_pulse_tb;

reg sys_clk; // 100MHz系统时钟
reg audio_clk; // 12.5MHz音频时钟
reg reset;
reg NewFrame; // 异步输入
wire ready; // 同步输出

// 实例化同步电路
sync_pulse sync_pulse_inst(
    .clk(sys_clk),
    .reset(reset),
    .in(NewFrame),
    .ready(ready)
);

// 系统时钟
initial begin
    sys_clk = 0;
    forever begin
        #5 sys_clk = ~sys_clk;
    end
end

// 音频时钟
initial begin
    audio_clk = 0;
    forever begin
        #40 audio_clk = ~audio_clk;
    end
end

// 测试
initial begin
    reset = 1; // 信号复位
    NewFrame = 0;
    #100;
    reset = 0;

    repeat (5) begin
        @(posedge audio_clk);
        NewFrame = 1;
        @(posedge audio_clk);
        NewFrame = 0;
        #1000;
    end

    #2000;
    $stop;
end

endmodule