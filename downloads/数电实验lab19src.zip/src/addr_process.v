// ============================================================================
// Module      : addr_process
// Description : 地址处理器。
//               根据 raw_addr 的高位区域标志，对地址进行直通或镜像翻转处理，
//               生成 ROM 读取地址 rom_addr。
// ============================================================================

module addr_process (
    input  wire [21:0] raw_addr,  // 原始 22 位地址
    output reg  [21:0] rom_addr   // 处理后的 ROM 地址
);

    // raw_addr[21:20] 用于判断当前地址所在区域。
    wire [1:0]  area           = raw_addr[21:20];

    // 镜像边界判断使用 11 位地址段。
    wire [10:0] raw_addr_20_10 = raw_addr[20:10];

    // 实际输出地址由 10 位地址段生成，赋值到 22 位 rom_addr 时高位补 0。
    wire [9:0]  raw_addr_19_10 = raw_addr[19:10];

    always @(*) begin
        case (area)
            // 区域 00 / 10：地址直通。
            2'b00,
            2'b10: begin
                rom_addr = {12'd0, raw_addr_19_10};
            end

            // 区域 01 / 11：地址镜像翻转。
            // 边界值 1024 单独映射到 1023，其余地址取二进制补码形式。
            2'b01,
            2'b11: begin
                if (raw_addr_20_10 == 11'd1024) begin
                    rom_addr = 22'd1023;
                end else begin
                    rom_addr = {12'd0, (~raw_addr_19_10 + 1'b1)};
                end
            end

            // 理论上 area 只会覆盖 00~11；default 用于完整性保护。
            default: begin
                rom_addr = 22'd0;
            end
        endcase
    end

endmodule
