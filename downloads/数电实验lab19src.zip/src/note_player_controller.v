//------------------------------------------------------------------------------
// Module: note_player_controller
// Description:
//   单音符播放控制器。
//   负责在加载音符、等待播放完成、产生 note_done 之间切换。
//------------------------------------------------------------------------------
module note_player_controller (
    input  wire clk,            // 时钟信号
    input  wire reset,          // 异步复位，高有效
    input  wire play_enable,    // 播放使能
    input  wire timer_done,     // 音符计时完成
    input  wire load_new_note,  // 新音符加载请求
    output reg  timer_clear,    // 清零音符计时器
    output reg  note_done,      // 当前音符完成脉冲
    output reg  load            // 音符寄存器加载使能
);

    localparam RESET = 2'b00,
               WAIT  = 2'b01,
               DONE  = 2'b10,
               LOAD  = 2'b11;

    reg [1:0] current_state;
    reg [1:0] next_state;

    // 状态寄存器
    always @(posedge clk or posedge reset) begin
        if (reset)
            current_state <= RESET;
        else
            current_state <= next_state;
    end

    // 次态逻辑
    always @(*) begin
        case (current_state)
            RESET: begin
                next_state = WAIT;
            end

            WAIT: begin
                if (play_enable) begin
                    if (timer_done)
                        next_state = DONE;
                    else if (load_new_note)
                        next_state = LOAD;
                    else
                        next_state = WAIT;
                end else begin
                    next_state = RESET;
                end
            end

            DONE: begin
                next_state = WAIT;
            end

            LOAD: begin
                next_state = WAIT;
            end

            default: begin
                next_state = RESET;
            end
        endcase
    end

    // 输出逻辑
    always @(*) begin
        case (current_state)
            RESET: begin
                timer_clear = 1'b1;
                note_done   = 1'b0;
                load        = 1'b0;
            end

            WAIT: begin
                timer_clear = 1'b0;
                note_done   = 1'b0;
                load        = 1'b0;
            end

            DONE: begin
                timer_clear = 1'b1;
                note_done   = 1'b1;
                load        = 1'b0;
            end

            LOAD: begin
                timer_clear = 1'b1;
                note_done   = 1'b0;
                load        = 1'b1;
            end

            default: begin
                timer_clear = 1'b0;
                note_done   = 1'b0;
                load        = 1'b0;
            end
        endcase
    end

endmodule
