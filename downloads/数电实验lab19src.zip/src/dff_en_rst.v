//------------------------------------------------------------------------------
// Module: dff_en_rst
// Description:
//   带异步复位和使能端的参数化 D 触发器。
//------------------------------------------------------------------------------
module dff_en_rst #(
    parameter WIDTH = 1
) (
    input  wire               clk,    // 时钟信号
    input  wire               reset,  // 异步复位，高有效
    input  wire               en,     // 写入使能，高有效
    input  wire [WIDTH-1:0]   d,      // 输入数据
    output reg  [WIDTH-1:0]   q       // 输出数据
);

    always @(posedge clk or posedge reset) begin
        if (reset)
            q <= {WIDTH{1'b0}};
        else if (en)
            q <= d;
    end

endmodule
