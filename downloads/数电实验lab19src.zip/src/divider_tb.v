// 分频器testbench
`timescale 1ns/1ps

module divider_tb;

// 测试信号
reg clk;
reg reset;
wire beat_1000;
wire beat_64; // 测试不同分频

divider #(
    .n(1000),
    .counter_bits(10)
) divider_1000_inst (
    .clk(clk),
    .reset(reset),
    .beat(beat_1000)
);

divider #(
    .n(64),
    .counter_bits(6)
) divider_64_inst (
    .clk(clk),
    .reset(reset),
    .beat(beat_64)
);

initial begin
    clk = 0;
    forever begin
        #5 clk = ~clk;
    end
end

initial begin
    // 初始复位
    reset = 1;
    #20;
    reset = 0;

    #2000000
    $stop;
end

endmodule