//------------------------------------------------------------------------------
// Module: data_process
// Description:
//   根据相位最高位对 ROM 输出的半周期数据进行符号处理。
//   当 area_bit 为 1 时输出补码形式，用于生成正弦波负半周期。
//------------------------------------------------------------------------------
module data_process (
    input  wire [15:0] raw_data,  // ROM 输出的原始波形数据
    input  wire        area_bit,  // 相位最高位：用于区分正/负半周期
    output reg  [15:0] data       // 处理后的波形采样数据
);

    // 组合逻辑：根据相位区域选择原码或补码输出
    always @(*) begin
        if (area_bit)
            data = ~raw_data + 1'b1;
        else
            data = raw_data;
    end

endmodule
