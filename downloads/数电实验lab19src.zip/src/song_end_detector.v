//------------------------------------------------------------------------------
// Module: song_end_detector
// Description:
//   歌曲结束检测模块。
//   当地址计数器进位或 ROM 中读到结束标记时，产生单周期 song_done 脉冲。
//------------------------------------------------------------------------------
module song_end_detector (
    input  wire        clk,        // 时钟信号
    input  wire        reset,      // 同步复位，高有效
    input  wire        co,         // 地址计数器进位标志
    input  wire [11:0] dout,       // song_rom 输出数据
    output reg         song_done   // 歌曲结束单周期脉冲
);

    wire cond = co || (dout[5:0] == 6'b0);  // 歌曲结束条件

    reg cond_reg;  // 上一拍结束条件，用于边沿检测

    always @(posedge clk) begin
        if (reset)
            cond_reg <= 1'b0;
        else
            cond_reg <= cond;
    end

    // 上升沿检测：cond 从 0 到 1 时输出一个周期脉冲
    always @(*) begin
        song_done = cond & ~cond_reg;
    end

endmodule
