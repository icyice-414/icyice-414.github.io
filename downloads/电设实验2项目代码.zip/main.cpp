#include <Arduino.h>
#include "ClockPlus.h"

void setup() {
  clockPlusSetup();
}

void loop() {
  clockPlusLoop();
}
