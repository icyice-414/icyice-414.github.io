#include "ClockPlus.h"

// ============================================================
// ArduinoClockFancy
// Arduino UNO + DS1302 + LCD1602 + LM35 + 3 buttons + buzzer
// 保留原实验功能，并加入：
// 1. 多模式菜单
// 2. EEPROM 保存用户设置
// 3. 三组闹钟 + 工作日/周末模式 + 贪睡
// 4. 秒表、倒计时、番茄钟
// 5. LCD 自定义字符动画、温度趋势、温度历史条形图
// 6. 多种蜂鸣旋律、隐藏彩蛋
// ============================================================

// -------------------- Pin map --------------------
LiquidCrystal lcd(12, 11, 5, 4, 3, 2); // RS,E,D4,D5,D6,D7

const int PIN_CHOOSE = A0;
const int PIN_ADD    = A1;
const int PIN_MINUS  = A2;
const int PIN_LM35   = A3;
const int PIN_BUZZER = 13;

const uint8_t CE_PIN   = 8;
const uint8_t IO_PIN   = 9;
const uint8_t SCLK_PIN = 10;
DS1302 rtc(CE_PIN, IO_PIN, SCLK_PIN);

// -------------------- Data structures --------------------
enum Mode : uint8_t {
  MODE_CLOCK = 0,
  MODE_TEMP,
  MODE_STOPWATCH,
  MODE_TIMER,
  MODE_POMODORO,
  MODE_HISTORY,
  MODE_COUNT
};

enum AlarmRepeat : uint8_t {
  REPEAT_EVERYDAY = 0,
  REPEAT_WORKDAY,
  REPEAT_WEEKEND
};

struct AlarmSetting {
  uint8_t hour;
  uint8_t minute;
  uint8_t enable;
  uint8_t repeat;
};

struct Settings {
  uint16_t magic;
  AlarmSetting alarms[3];
  int16_t tempAlarm10;        // 温度阈值 * 10
  uint8_t timerH;
  uint8_t timerM;
  uint8_t timerS;
  uint8_t pomoWorkMin;
  uint8_t pomoBreakMin;
};

const uint16_t EEPROM_MAGIC = 0x52A6;
Settings cfg;

// -------------------- State variables --------------------
Mode currentMode = MODE_CLOCK;
Mode lastMode = MODE_COUNT;

unsigned long lastDisplayMillis = 0;
unsigned long lastTempSampleMillis = 0;
unsigned long lastTempAlarmMillis = 0;
unsigned long lastAnimMillis = 0;
uint8_t animFrame = 0;

float currentTemp = 0.0;
float minTemp = 100.0;
float maxTemp = -100.0;
float previousTrendTemp = 0.0;
int8_t tempTrend = 0; // -1 down, 0 flat, 1 up

const uint8_t HISTORY_SIZE = 16;
float tempHistory[HISTORY_SIZE];
uint8_t tempHistoryCount = 0;
uint8_t tempHistoryIndex = 0;

long lastHourChimeKey = -1;
long lastAlarmKey[3] = {-1, -1, -1};

bool ringing = false;
uint8_t ringingType = 0; // 1 alarm, 2 timer, 3 pomo
unsigned long ringingStartMillis = 0;

// 温度报警不再进入 ringing 页面，避免 LCD 被反复 clear 后看不见。
// 它只在正常时钟页面叠加 ! 标记，并用非阻塞 tone() 提醒。
bool tempAlarmActive = false;
unsigned long lastTempAlarmBeepMillis = 0;
uint8_t activeAlarmIndex = 0;
bool snoozeActive = false;
uint8_t snoozeHour = 0;
uint8_t snoozeMinute = 0;
long lastSnoozeKey = -1;

// Stopwatch
bool stopwatchRunning = false;
unsigned long stopwatchStartMillis = 0;
unsigned long stopwatchAccumMillis = 0;

// Countdown
bool timerRunning = false;
unsigned long timerRemainMillis = 0;
unsigned long timerLastMillis = 0;

// Pomodoro
bool pomoRunning = false;
bool pomoWorkPhase = true;
uint8_t pomoRound = 1;
unsigned long pomoRemainMillis = 0;
unsigned long pomoLastMillis = 0;

// LCD custom character mode: 0 none, 1 icons, 2 bars
uint8_t charSetMode = 0;

// -------------------- Musical notes --------------------
#define NOTE_C5  523
#define NOTE_D5  587
#define NOTE_E5  659
#define NOTE_F5  698
#define NOTE_G5  784
#define NOTE_A5  880
#define NOTE_B5  988
#define NOTE_C6 1047
#define NOTE_D6 1175
#define NOTE_E6 1319
#define NOTE_G6 1568

// -------------------- Utility --------------------
bool keyDown(int pin) {
  return digitalRead(pin) == LOW;
}

bool keyPressed(int pin) {
  if (digitalRead(pin) == LOW) {
    delay(20);
    if (digitalRead(pin) == LOW) {
      while (digitalRead(pin) == LOW) delay(5);
      return true;
    }
  }
  return false;
}

void clearLine(uint8_t row) {
  lcd.setCursor(0, row);
  lcd.print("                ");
}

void print2(int n) {
  if (n < 10) lcd.print('0');
  lcd.print(n);
}

void print4(int n) {
  if (n < 1000) lcd.print('0');
  if (n < 100)  lcd.print('0');
  if (n < 10)   lcd.print('0');
  lcd.print(n);
}

bool isLeapYear(int y) {
  return (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
}

int daysInMonth(int y, int m) {
  switch (m) {
    case 1: case 3: case 5: case 7: case 8: case 10: case 12: return 31;
    case 4: case 6: case 9: case 11: return 30;
    case 2: return isLeapYear(y) ? 29 : 28;
  }
  return 30;
}

void fixDate(int &y, int &m, int &d) {
  if (y < 2000) y = 2000;
  if (y > 2099) y = 2099;
  if (m < 1) m = 12;
  if (m > 12) m = 1;
  int md = daysInMonth(y, m);
  if (d < 1) d = md;
  if (d > md) d = 1;
}

// Return 0..6 = Mon..Sun
int weekIndex(int y, int m, int d) {
  if (m == 1) { m = 13; y--; }
  else if (m == 2) { m = 14; y--; }
  return (d + 2 * m + 3 * (m + 1) / 5 + y + y / 4 - y / 100 + y / 400) % 7;
}

const char* weekName(int y, int m, int d) {
  static const char* names[] = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
  return names[weekIndex(y, m, d)];
}

Time::Day ds1302DayFromDate(int y, int m, int d) {
  switch (weekIndex(y, m, d)) {
    case 0: return Time::kMonday;
    case 1: return Time::kTuesday;
    case 2: return Time::kWednesday;
    case 3: return Time::kThursday;
    case 4: return Time::kFriday;
    case 5: return Time::kSaturday;
    case 6: return Time::kSunday;
  }
  return Time::kMonday;
}

float readTemperature() {
  int value = analogRead(PIN_LM35);
  // LM35: 10 mV / degree C. Arduino UNO ADC: 0~1023 corresponds to 0~5V.
  return 500.0 * value / 1023.0;
}

void sampleTemperature(bool force = false) {
  if (!force && millis() - lastTempSampleMillis < 2000) return;
  lastTempSampleMillis = millis();

  float t = readTemperature();
  currentTemp = t;
  if (t > maxTemp) maxTemp = t;
  if (t < minTemp) minTemp = t;

  if (t > previousTrendTemp + 0.3) tempTrend = 1;
  else if (t < previousTrendTemp - 0.3) tempTrend = -1;
  else tempTrend = 0;
  previousTrendTemp = t;

  // 每次采样都更新历史，16格循环
  tempHistory[tempHistoryIndex] = t;
  tempHistoryIndex = (tempHistoryIndex + 1) % HISTORY_SIZE;
  if (tempHistoryCount < HISTORY_SIZE) tempHistoryCount++;
}

// -------------------- Custom characters --------------------
void loadIconChars() {
  if (charSetMode == 1) return;
  charSetMode = 1;

  byte bell[8]  = {0x04,0x0E,0x0E,0x0E,0x1F,0x00,0x04,0x00};
  byte up[8]    = {0x04,0x0E,0x15,0x04,0x04,0x04,0x04,0x00};
  byte down[8]  = {0x04,0x04,0x04,0x04,0x15,0x0E,0x04,0x00};
  byte flat[8]  = {0x00,0x00,0x00,0x1F,0x1F,0x00,0x00,0x00};
  byte heart1[8]= {0x00,0x0A,0x1F,0x1F,0x0E,0x04,0x00,0x00};
  byte heart2[8]= {0x00,0x00,0x0A,0x15,0x11,0x0A,0x04,0x00};
  byte hourg[8] = {0x1F,0x11,0x0A,0x04,0x0A,0x11,0x1F,0x00};
  byte note[8]  = {0x02,0x03,0x02,0x0E,0x1E,0x0C,0x00,0x00};

  lcd.createChar(0, bell);
  lcd.createChar(1, up);
  lcd.createChar(2, down);
  lcd.createChar(3, flat);
  lcd.createChar(4, heart1);
  lcd.createChar(5, heart2);
  lcd.createChar(6, hourg);
  lcd.createChar(7, note);
}

void loadBarChars() {
  if (charSetMode == 2) return;
  charSetMode = 2;

  for (uint8_t level = 0; level < 8; level++) {
    byte b[8];
    for (uint8_t row = 0; row < 8; row++) {
      b[row] = (row >= 7 - level) ? 0x1F : 0x00;
    }
    lcd.createChar(level, b);
  }
}

// -------------------- Sound --------------------
void playToneBlocking(int freq, int ms) {
  tone(PIN_BUZZER, freq, ms);
  delay(ms + 20);
  noTone(PIN_BUZZER);
}

void playClick() {
  tone(PIN_BUZZER, NOTE_C6, 40);
  delay(45);
  noTone(PIN_BUZZER);
}

void playHourChime() {
  playToneBlocking(NOTE_C6, 80);
  playToneBlocking(NOTE_G6, 120);
}

void playAlarmMelody(uint8_t alarmIndex) {
  if (alarmIndex == 0) {
    int notes[] = {NOTE_C5, NOTE_E5, NOTE_G5, NOTE_C6};
    for (uint8_t i = 0; i < 4; i++) playToneBlocking(notes[i], 90);
  } else if (alarmIndex == 1) {
    int notes[] = {NOTE_G5, NOTE_G5, NOTE_A5, NOTE_G5, NOTE_C6, NOTE_B5};
    for (uint8_t i = 0; i < 6; i++) playToneBlocking(notes[i], 120);
  } else {
    int notes[] = {NOTE_C6, NOTE_B5, NOTE_A5, NOTE_G5, NOTE_A5, NOTE_B5, NOTE_C6};
    for (uint8_t i = 0; i < 7; i++) playToneBlocking(notes[i], 70);
  }
}

void playTimerDone() {
  for (uint8_t i = 0; i < 3; i++) {
    playToneBlocking(NOTE_E6, 100);
    delay(40);
  }
}

void playSecretTune() {
  int notes[] = {NOTE_C5, NOTE_D5, NOTE_E5, NOTE_G5, NOTE_E5, NOTE_G5, NOTE_C6};
  for (uint8_t i = 0; i < 7; i++) playToneBlocking(notes[i], 90);
}

void startRinging(uint8_t type, uint8_t alarmIdx = 0) {
  ringing = true;
  ringingType = type;
  ringingStartMillis = millis();
  activeAlarmIndex = alarmIdx;

  if (type == 1) playAlarmMelody(alarmIdx);
  else if (type == 2 || type == 3) playTimerDone();
  else if (type == 4) playToneBlocking(NOTE_D6, 120);
}

void stopRinging() {
  ringing = false;
  ringingType = 0;
  noTone(PIN_BUZZER);
}

// -------------------- EEPROM --------------------
void setDefaultSettings() {
  cfg.magic = EEPROM_MAGIC;
  cfg.alarms[0] = {7, 30, 1, REPEAT_EVERYDAY};
  cfg.alarms[1] = {12, 0, 0, REPEAT_WORKDAY};
  cfg.alarms[2] = {22, 30, 0, REPEAT_EVERYDAY};
  cfg.tempAlarm10 = 300;
  cfg.timerH = 0;
  cfg.timerM = 5;
  cfg.timerS = 0;
  cfg.pomoWorkMin = 25;
  cfg.pomoBreakMin = 5;
}

void saveSettings() {
  EEPROM.put(0, cfg);
}

void loadSettings() {
  EEPROM.get(0, cfg);
  if (cfg.magic != EEPROM_MAGIC || cfg.tempAlarm10 < 0 || cfg.tempAlarm10 > 990) {
    setDefaultSettings();
    saveSettings();
  }
  for (uint8_t i = 0; i < 3; i++) {
    if (cfg.alarms[i].hour > 23) cfg.alarms[i].hour = 7;
    if (cfg.alarms[i].minute > 59) cfg.alarms[i].minute = 0;
    if (cfg.alarms[i].repeat > 2) cfg.alarms[i].repeat = REPEAT_EVERYDAY;
  }
  if (cfg.timerH > 23) cfg.timerH = 0;
  if (cfg.timerM > 59) cfg.timerM = 5;
  if (cfg.timerS > 59) cfg.timerS = 0;
  if (cfg.pomoWorkMin < 1 || cfg.pomoWorkMin > 60) cfg.pomoWorkMin = 25;
  if (cfg.pomoBreakMin < 1 || cfg.pomoBreakMin > 30) cfg.pomoBreakMin = 5;
}

// -------------------- Display screens --------------------
void displayClock(Time t) {
  loadIconChars();
  clearLine(0);
  lcd.setCursor(0, 0);
  print4(t.yr); lcd.print('-'); print2(t.mon); lcd.print('-'); print2(t.date);
  lcd.print(' '); lcd.print(weekName(t.yr, t.mon, t.date));

  clearLine(1);
  lcd.setCursor(0, 1);
  print2(t.hr); lcd.print(':'); print2(t.min); lcd.print(':'); print2(t.sec);

  lcd.setCursor(9, 1);
  if (tempAlarmActive) {
    lcd.print('!');
  } else if (cfg.alarms[0].enable || cfg.alarms[1].enable || cfg.alarms[2].enable) {
    lcd.write((uint8_t)0);
  } else {
    lcd.print(' ');
  }

  lcd.print(currentTemp, 1);
  if (tempTrend > 0) lcd.write((uint8_t)1);
  else if (tempTrend < 0) lcd.write((uint8_t)2);
  else lcd.write((uint8_t)3);
}

void displayTempStats() {
  loadIconChars();
  clearLine(0);
  lcd.setCursor(0, 0);
  lcd.print("Temp "); lcd.print(currentTemp, 1);
  if (tempTrend > 0) lcd.write((uint8_t)1);
  else if (tempTrend < 0) lcd.write((uint8_t)2);
  else lcd.write((uint8_t)3);

  clearLine(1);
  lcd.setCursor(0, 1);
  lcd.print("H"); lcd.print(maxTemp, 1);
  lcd.print(" L"); lcd.print(minTemp, 1);
}

void displayStopwatch() {
  loadIconChars();
  unsigned long elapsed = stopwatchAccumMillis;
  if (stopwatchRunning) elapsed += millis() - stopwatchStartMillis;

  unsigned long tenths = elapsed / 100;
  uint8_t tenth = tenths % 10;
  unsigned long totalSec = elapsed / 1000;
  uint8_t sec = totalSec % 60;
  uint8_t min = (totalSec / 60) % 60;
  uint8_t hr = (totalSec / 3600) % 100;

  clearLine(0);
  lcd.setCursor(0, 0);
  lcd.print("Stopwatch ");
  lcd.print(stopwatchRunning ? "Run" : "Pause");

  clearLine(1);
  lcd.setCursor(0, 1);
  print2(hr); lcd.print(':'); print2(min); lcd.print(':'); print2(sec); lcd.print('.'); lcd.print(tenth);
}

unsigned long presetTimerMillis() {
  unsigned long s = (unsigned long)cfg.timerH * 3600UL + (unsigned long)cfg.timerM * 60UL + cfg.timerS;
  if (s == 0) s = 60;
  return s * 1000UL;
}

void displayTimer() {
  loadIconChars();
  unsigned long remain = timerRemainMillis;
  unsigned long totalSec = remain / 1000;
  uint8_t sec = totalSec % 60;
  uint8_t min = (totalSec / 60) % 60;
  uint8_t hr = (totalSec / 3600) % 100;

  clearLine(0);
  lcd.setCursor(0, 0);
  lcd.write((uint8_t)6);
  lcd.print(" Countdown ");
  lcd.print(timerRunning ? "Run" : "Stop");

  clearLine(1);
  lcd.setCursor(0, 1);
  print2(hr); lcd.print(':'); print2(min); lcd.print(':'); print2(sec);
}

void displayPomodoro() {
  loadIconChars();
  unsigned long totalSec = pomoRemainMillis / 1000;
  uint8_t sec = totalSec % 60;
  uint8_t min = (totalSec / 60) % 60;

  clearLine(0);
  lcd.setCursor(0, 0);
  lcd.print("Pomo ");
  lcd.print(pomoWorkPhase ? "Work " : "Break");
  lcd.print(pomoRound); lcd.print("/4");
  lcd.setCursor(15, 0);
  lcd.write((uint8_t)(animFrame % 2 ? 4 : 5));

  clearLine(1);
  lcd.setCursor(0, 1);
  print2(min); lcd.print(':'); print2(sec);
  lcd.print(pomoRunning ? " Focus!" : " Pause ");
}

void displayHistory() {
  loadBarChars();
  clearLine(0);
  lcd.setCursor(0, 0);
  lcd.print("Temp History");

  clearLine(1);
  lcd.setCursor(0, 1);
  if (tempHistoryCount == 0) {
    lcd.print("No data");
    return;
  }

  float lo = 100.0, hi = -100.0;
  for (uint8_t i = 0; i < tempHistoryCount; i++) {
    float v = tempHistory[i];
    if (v < lo) lo = v;
    if (v > hi) hi = v;
  }
  if (hi - lo < 0.5) hi = lo + 0.5;

  for (uint8_t col = 0; col < 16; col++) {
    if (col >= tempHistoryCount) {
      lcd.print(' ');
    } else {
      uint8_t idx = (tempHistoryIndex + HISTORY_SIZE - tempHistoryCount + col) % HISTORY_SIZE;
      float v = tempHistory[idx];
      int level = (int)((v - lo) * 7.0 / (hi - lo) + 0.5);
      if (level < 0) level = 0;
      if (level > 7) level = 7;
      lcd.write((uint8_t)level);
    }
  }
}

void displayMode() {
  Time t = rtc.time();
  switch (currentMode) {
    case MODE_CLOCK: displayClock(t); break;
    case MODE_TEMP: displayTempStats(); break;
    case MODE_STOPWATCH: displayStopwatch(); break;
    case MODE_TIMER: displayTimer(); break;
    case MODE_POMODORO: displayPomodoro(); break;
    case MODE_HISTORY: displayHistory(); break;
    default: break;
  }
}

// -------------------- Settings screens --------------------
const char* repeatName(uint8_t r) {
  if (r == REPEAT_WORKDAY) return "Work";
  if (r == REPEAT_WEEKEND) return "Wkend";
  return "Every";
}

void displaySetting(uint8_t field, uint8_t alarmIndex) {
  loadIconChars();
  clearLine(0);
  clearLine(1);
  lcd.setCursor(0, 0);

  if (field <= 4) {
    lcd.print("Alarm"); lcd.print(alarmIndex + 1);
    lcd.print(cfg.alarms[alarmIndex].enable ? " ON " : " OFF");
    lcd.print(repeatName(cfg.alarms[alarmIndex].repeat));
    lcd.setCursor(0, 1);
    print2(cfg.alarms[alarmIndex].hour); lcd.print(':'); print2(cfg.alarms[alarmIndex].minute);
    lcd.print(" Sel/+/-. ");
    if (field == 0) lcd.setCursor(5, 0);       // alarm index
    else if (field == 1) lcd.setCursor(7, 0);  // on off
    else if (field == 2) lcd.setCursor(0, 1);  // hour
    else if (field == 3) lcd.setCursor(3, 1);  // minute
    else lcd.setCursor(10, 0);                 // repeat
  } else if (field == 5) {
    lcd.print("Temp Alarm");
    lcd.setCursor(0, 1);
    lcd.print(cfg.tempAlarm10 / 10.0, 1); lcd.print("C");
    lcd.setCursor(0, 1);
  } else if (field >= 6 && field <= 8) {
    lcd.print("Timer Preset");
    lcd.setCursor(0, 1);
    print2(cfg.timerH); lcd.print(':'); print2(cfg.timerM); lcd.print(':'); print2(cfg.timerS);
    if (field == 6) lcd.setCursor(0, 1);
    else if (field == 7) lcd.setCursor(3, 1);
    else lcd.setCursor(6, 1);
  } else if (field == 9) {
    lcd.print("Pomo Work Min");
    lcd.setCursor(0, 1);
    print2(cfg.pomoWorkMin); lcd.print(" min");
    lcd.setCursor(0, 1);
  } else if (field == 10) {
    lcd.print("Pomo Break Min");
    lcd.setCursor(0, 1);
    print2(cfg.pomoBreakMin); lcd.print(" min");
    lcd.setCursor(0, 1);
  }
  lcd.cursor();
}

void enterSettings() {
  uint8_t field = 0;
  uint8_t alarmIndex = 0;
  lcd.cursor();
  playClick();

  while (true) {
    displaySetting(field, alarmIndex);

    if (keyPressed(PIN_CHOOSE)) {
      field++;
      if (field > 10) break;
    }
    if (keyPressed(PIN_ADD)) {
      AlarmSetting &a = cfg.alarms[alarmIndex];
      switch (field) {
        case 0: alarmIndex = (alarmIndex + 1) % 3; break;
        case 1: a.enable = !a.enable; break;
        case 2: a.hour = (a.hour + 1) % 24; break;
        case 3: a.minute = (a.minute + 1) % 60; break;
        case 4: a.repeat = (a.repeat + 1) % 3; break;
        case 5: cfg.tempAlarm10 += 10; if (cfg.tempAlarm10 > 990) cfg.tempAlarm10 = 990; break;
        case 6: cfg.timerH = (cfg.timerH + 1) % 24; break;
        case 7: cfg.timerM = (cfg.timerM + 1) % 60; break;
        case 8: cfg.timerS = (cfg.timerS + 1) % 60; break;
        case 9: cfg.pomoWorkMin++; if (cfg.pomoWorkMin > 60) cfg.pomoWorkMin = 1; break;
        case 10: cfg.pomoBreakMin++; if (cfg.pomoBreakMin > 30) cfg.pomoBreakMin = 1; break;
      }
    }
    if (keyPressed(PIN_MINUS)) {
      AlarmSetting &a = cfg.alarms[alarmIndex];
      switch (field) {
        case 0: alarmIndex = (alarmIndex + 2) % 3; break;
        case 1: a.enable = !a.enable; break;
        case 2: a.hour = (a.hour + 23) % 24; break;
        case 3: a.minute = (a.minute + 59) % 60; break;
        case 4: a.repeat = (a.repeat + 2) % 3; break;
        case 5: cfg.tempAlarm10 -= 10; if (cfg.tempAlarm10 < 0) cfg.tempAlarm10 = 0; break;
        case 6: cfg.timerH = (cfg.timerH + 23) % 24; break;
        case 7: cfg.timerM = (cfg.timerM + 59) % 60; break;
        case 8: cfg.timerS = (cfg.timerS + 59) % 60; break;
        case 9: cfg.pomoWorkMin = (cfg.pomoWorkMin <= 1) ? 60 : cfg.pomoWorkMin - 1; break;
        case 10: cfg.pomoBreakMin = (cfg.pomoBreakMin <= 1) ? 30 : cfg.pomoBreakMin - 1; break;
      }
    }
    delay(80);
  }

  saveSettings();
  timerRemainMillis = presetTimerMillis();
  pomoRemainMillis = (unsigned long)cfg.pomoWorkMin * 60000UL;
  lcd.noCursor();
  lcd.clear();
  playTimerDone();
}

void displayTimeSetting(uint8_t field, int y, int mon, int d, int h, int m, int s) {
  clearLine(0); clearLine(1);
  lcd.setCursor(0, 0);
  print4(y); lcd.print('-'); print2(mon); lcd.print('-'); print2(d);
  lcd.setCursor(0, 1);
  print2(h); lcd.print(':'); print2(m); lcd.print(':'); print2(s); lcd.print(" Set");

  switch (field) {
    case 0: lcd.setCursor(0, 1); break;
    case 1: lcd.setCursor(3, 1); break;
    case 2: lcd.setCursor(6, 1); break;
    case 3: lcd.setCursor(8, 0); break;
    case 4: lcd.setCursor(5, 0); break;
    case 5: lcd.setCursor(0, 0); break;
  }
  lcd.cursor();
}

void enterTimeSetting() {
  loadIconChars();
  Time t = rtc.time();
  int y = t.yr, mon = t.mon, d = t.date, h = t.hr, m = t.min, s = t.sec;
  fixDate(y, mon, d);
  uint8_t field = 0;
  lcd.cursor();
  playClick();

  while (true) {
    fixDate(y, mon, d);
    displayTimeSetting(field, y, mon, d, h, m, s);
    if (keyPressed(PIN_CHOOSE)) {
      field++;
      if (field > 5) break;
    }
    if (keyPressed(PIN_ADD)) {
      switch (field) {
        case 0: h = (h + 1) % 24; break;
        case 1: m = (m + 1) % 60; break;
        case 2: s = (s + 1) % 60; break;
        case 3: d++; break;
        case 4: mon++; break;
        case 5: y++; break;
      }
    }
    if (keyPressed(PIN_MINUS)) {
      switch (field) {
        case 0: h = (h + 23) % 24; break;
        case 1: m = (m + 59) % 60; break;
        case 2: s = (s + 59) % 60; break;
        case 3: d--; break;
        case 4: mon--; break;
        case 5: y--; break;
      }
    }
    delay(80);
  }

  fixDate(y, mon, d);
  rtc.time(Time(y, mon, d, h, m, s, ds1302DayFromDate(y, mon, d)));
  lcd.noCursor();
  lcd.clear();
  playTimerDone();
}

// -------------------- Alarm logic --------------------
bool alarmRepeatMatches(uint8_t repeat, Time t) {
  int w = weekIndex(t.yr, t.mon, t.date); // Mon=0, Sun=6
  if (repeat == REPEAT_EVERYDAY) return true;
  if (repeat == REPEAT_WORKDAY) return w >= 0 && w <= 4;
  if (repeat == REPEAT_WEEKEND) return w == 5 || w == 6;
  return true;
}

long dayMinuteKey(Time t, uint8_t h, uint8_t m) {
  return (long)t.yr * 100000000L + (long)t.mon * 1000000L + (long)t.date * 10000L + (long)h * 100L + m;
}

void checkHourChime(Time t) {
  long key = (long)t.yr * 1000000L + (long)t.mon * 10000L + (long)t.date * 100L + t.hr;
  if (t.min == 0 && t.sec == 0 && key != lastHourChimeKey) {
    lastHourChimeKey = key;
    playHourChime();
  }
}

void checkAlarms(Time t) {
  for (uint8_t i = 0; i < 3; i++) {
    AlarmSetting &a = cfg.alarms[i];
    if (!a.enable) continue;
    long key = dayMinuteKey(t, a.hour, a.minute);
    if (t.hr == a.hour && t.min == a.minute && t.sec == 0 && alarmRepeatMatches(a.repeat, t) && key != lastAlarmKey[i]) {
      lastAlarmKey[i] = key;
      startRinging(1, i);
    }
  }

  if (snoozeActive) {
    long key = dayMinuteKey(t, snoozeHour, snoozeMinute);
    if (t.hr == snoozeHour && t.min == snoozeMinute && t.sec == 0 && key != lastSnoozeKey) {
      lastSnoozeKey = key;
      snoozeActive = false;
      startRinging(1, activeAlarmIndex);
    }
  }
}

void checkTemperatureAlarm() {
  float alarmTemp = cfg.tempAlarm10 / 10.0;

  // 温度降到阈值以下一点后自动解除，留 0.3℃ 回差防止临界点反复闪烁。
  if (currentTemp < alarmTemp - 0.3) {
    tempAlarmActive = false;
    return;
  }

  if (currentTemp < alarmTemp) return;

  tempAlarmActive = true;

  // 只用非阻塞 tone() 提醒，不 delay，不 lcd.clear，不进入报警专用界面。
  // 这样 LCD 会一直保持正常时钟界面，避免报警后整屏看不清。
  unsigned long now = millis();
  float over = currentTemp - alarmTemp;
  unsigned long interval = 2500UL;
  int freq = NOTE_D6;

  if (over >= 10.0) {
    interval = 700UL;
    freq = NOTE_E6;
  } else if (over >= 5.0) {
    interval = 1200UL;
    freq = NOTE_D6;
  }

  if (now - lastTempAlarmBeepMillis >= interval) {
    lastTempAlarmBeepMillis = now;
    tone(PIN_BUZZER, freq, 80);
  }
}

void handleRingingButtons() {
  if (!ringing) return;

  loadIconChars();
  clearLine(0); clearLine(1);

  // 温度报警不再使用 ringing 页面。


  lcd.setCursor(0, 0);
  if (ringingType == 1) {
    lcd.write((uint8_t)0); lcd.print(" Alarm"); lcd.print(activeAlarmIndex + 1);
  } else if (ringingType == 2) {
    lcd.write((uint8_t)6); lcd.print(" Timer Done");
  } else if (ringingType == 3) {
    lcd.print("Pomodoro Done");
  }
  lcd.setCursor(0, 1);
  lcd.print("SEL off +5 -10");

  if (keyPressed(PIN_CHOOSE)) {
    stopRinging();
    lcd.clear();
    return;
  }
  if (keyPressed(PIN_ADD)) {
    Time t = rtc.time();
    int total = t.hr * 60 + t.min + 5;
    snoozeHour = (total / 60) % 24;
    snoozeMinute = total % 60;
    snoozeActive = true;
    stopRinging();
    lcd.clear();
    return;
  }
  if (keyPressed(PIN_MINUS)) {
    Time t = rtc.time();
    int total = t.hr * 60 + t.min + 10;
    snoozeHour = (total / 60) % 24;
    snoozeMinute = total % 60;
    snoozeActive = true;
    stopRinging();
    lcd.clear();
    return;
  }

  // 20秒后自动停止蜂鸣界面，避免一直阻塞展示
  if (millis() - ringingStartMillis > 20000UL) {
    stopRinging();
    lcd.clear();
  }
}

// -------------------- Mode logic --------------------
void nextMode() {
  currentMode = (Mode)((currentMode + 1) % MODE_COUNT);
  lcd.clear();
  charSetMode = 0;
}

void prevMode() {
  currentMode = (Mode)((currentMode + MODE_COUNT - 1) % MODE_COUNT);
  lcd.clear();
  charSetMode = 0;
}

void updateCountdown() {
  if (!timerRunning) return;
  unsigned long now = millis();
  unsigned long delta = now - timerLastMillis;
  timerLastMillis = now;
  if (delta >= timerRemainMillis) {
    timerRemainMillis = 0;
    timerRunning = false;
    startRinging(2);
  } else {
    timerRemainMillis -= delta;
  }
}

void updatePomodoro() {
  if (!pomoRunning) return;
  unsigned long now = millis();
  unsigned long delta = now - pomoLastMillis;
  pomoLastMillis = now;

  if (delta >= pomoRemainMillis) {
    pomoRunning = false;
    startRinging(3);
    if (pomoWorkPhase) {
      pomoWorkPhase = false;
      pomoRemainMillis = (unsigned long)cfg.pomoBreakMin * 60000UL;
    } else {
      pomoWorkPhase = true;
      pomoRound++;
      if (pomoRound > 4) pomoRound = 1;
      pomoRemainMillis = (unsigned long)cfg.pomoWorkMin * 60000UL;
    }
  } else {
    pomoRemainMillis -= delta;
  }
}

void showSecret() {
  loadIconChars();
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(" Secret Mode ");
  lcd.write((uint8_t)4);
  lcd.setCursor(0, 1);
  lcd.print("Hello Teacher!");
  playSecretTune();
  delay(1000);
  lcd.clear();
}

void waitAllKeysRelease() {
  while (keyDown(PIN_CHOOSE) || keyDown(PIN_ADD) || keyDown(PIN_MINUS)) {
    delay(5);
  }
  delay(30);
}

void enterSettingsPrompt() {
  lcd.noCursor();
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Enter Settings");
  lcd.setCursor(0, 1);
  lcd.print("Release keys...");
  playClick();
  waitAllKeysRelease();
  enterSettings();
}

void handleMinusSingleAction() {
  if (currentMode == MODE_STOPWATCH) {
    stopwatchRunning = false;
    stopwatchAccumMillis = 0;
  } else if (currentMode == MODE_TIMER) {
    timerRunning = false;
    timerRemainMillis = presetTimerMillis();
  } else if (currentMode == MODE_POMODORO) {
    pomoRunning = false;
    pomoWorkPhase = true;
    pomoRound = 1;
    pomoRemainMillis = (unsigned long)cfg.pomoWorkMin * 60000UL;
  } else {
    prevMode();
  }
  playClick();
}

void handleChooseAction() {
  if (currentMode == MODE_CLOCK) {
    enterTimeSetting();
  } else if (currentMode == MODE_STOPWATCH) {
    if (stopwatchRunning) {
      stopwatchAccumMillis += millis() - stopwatchStartMillis;
      stopwatchRunning = false;
    } else {
      stopwatchStartMillis = millis();
      stopwatchRunning = true;
    }
  } else if (currentMode == MODE_TIMER) {
    if (timerRemainMillis == 0) timerRemainMillis = presetTimerMillis();
    timerRunning = !timerRunning;
    timerLastMillis = millis();
  } else if (currentMode == MODE_POMODORO) {
    pomoRunning = !pomoRunning;
    pomoLastMillis = millis();
  }
  playClick();
}

void handleButtons() {
  // 温度报警只作为“叠加提示”存在：
  // LCD 第二行用 ! 标记超温，蜂鸣器短响；
  // 但不抢占按键，因此报警时仍可切换界面、进入设置、操作秒表/倒计时。

  // 优化后的 + / - 组合键识别：
  // 原来必须几乎完全同时按下，先按到的那个键会被当作单键处理。
  // 现在只要先按下 + 或 - 后，在约 0.6 秒内补按另一个键，就进入综合设置。
  if (keyDown(PIN_ADD) || keyDown(PIN_MINUS)) {
    bool addFirst = keyDown(PIN_ADD);
    bool minusFirst = keyDown(PIN_MINUS);
    unsigned long start = millis();
    bool combo = false;

    while (millis() - start < 650UL) {
      if (keyDown(PIN_ADD) && keyDown(PIN_MINUS)) {
        combo = true;
        break;
      }
      // 两个键都已经松开，说明这是一次很短的单键点击，不再继续等待。
      if (!keyDown(PIN_ADD) && !keyDown(PIN_MINUS)) {
        break;
      }
      delay(5);
    }

    if (combo) {
      enterSettingsPrompt();
      return;
    }

    // 没有补按成组合键，则按原来的单键功能处理。
    waitAllKeysRelease();
    if (addFirst && !minusFirst) {
      nextMode();
      playClick();
      return;
    }
    if (minusFirst && !addFirst) {
      handleMinusSingleAction();
      return;
    }
  }

  // 隐藏彩蛋仍保留，但优先级低于 + / - 综合设置。
  if (keyDown(PIN_CHOOSE) && keyDown(PIN_ADD)) {
    delay(80);
    if (keyDown(PIN_CHOOSE) && keyDown(PIN_ADD)) {
      waitAllKeysRelease();
      showSecret();
      return;
    }
  }

  // 选择键增加“长按进入综合设置”的备用入口，现场演示更稳。
  if (keyDown(PIN_CHOOSE)) {
    unsigned long start = millis();
    bool longPress = false;

    while (keyDown(PIN_CHOOSE)) {
      if (millis() - start >= 900UL) {
        longPress = true;
        break;
      }
      delay(5);
    }

    if (longPress) {
      enterSettingsPrompt();
      return;
    }

    // 短按选择键仍按原功能执行：时钟界面进入时间设置，其它界面开始/暂停。
    handleChooseAction();
    return;
  }
}

// -------------------- Setup and loop --------------------
void splash() {
  loadIconChars();
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Clock Fancy ");
  lcd.write((uint8_t)4);
  lcd.setCursor(0, 1);
  lcd.print("Loading");
  for (uint8_t i = 0; i < 6; i++) {
    lcd.print('.');
    tone(PIN_BUZZER, NOTE_C5 + i * 80, 40);
    delay(120);
  }
  noTone(PIN_BUZZER);
  lcd.clear();
}

void clockPlusSetup() {
  pinMode(PIN_CHOOSE, INPUT_PULLUP);
  pinMode(PIN_ADD, INPUT_PULLUP);
  pinMode(PIN_MINUS, INPUT_PULLUP);
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_LM35, INPUT);

  lcd.begin(16, 2);
  lcd.clear();

  rtc.writeProtect(false);
  rtc.halt(false);

  // 第一次校时使用：取消下一行注释，改成当前时间，烧录一次；
  // 然后必须重新注释掉再烧录一次，否则每次重启都会重置时间。
  // rtc.time(Time(2026, 5, 26, 12, 0, 0, Time::kTuesday));

  loadSettings();
  timerRemainMillis = presetTimerMillis();
  pomoRemainMillis = (unsigned long)cfg.pomoWorkMin * 60000UL;
  sampleTemperature(true);
  for (uint8_t i = 0; i < HISTORY_SIZE; i++) tempHistory[i] = currentTemp;
  tempHistoryCount = HISTORY_SIZE;

  splash();
}

void clockPlusLoop() {
  if (ringing) {
    handleRingingButtons();
    return;
  }

  Time t = rtc.time();

  sampleTemperature(false);
  updateCountdown();
  updatePomodoro();

  if (millis() - lastAnimMillis >= 500) {
    lastAnimMillis = millis();
    animFrame++;
  }

  handleButtons();

  checkHourChime(t);
  checkAlarms(t);
  checkTemperatureAlarm();

  if (currentMode != lastMode) {
    lastMode = currentMode;
    lcd.clear();
    charSetMode = 0;
  }

  if (millis() - lastDisplayMillis >= 250) {
    lastDisplayMillis = millis();
    displayMode();
  }
}
