#ifndef CLOCK_PLUS_H
#define CLOCK_PLUS_H

#include <Arduino.h>
#include <DS1302.h>
#include <LiquidCrystal.h>
#include <EEPROM.h>

void clockPlusSetup();
void clockPlusLoop();

#endif
